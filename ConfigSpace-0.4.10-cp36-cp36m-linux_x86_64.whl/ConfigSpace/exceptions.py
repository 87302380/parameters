class ForbiddenValueError(ValueError):
    pass
