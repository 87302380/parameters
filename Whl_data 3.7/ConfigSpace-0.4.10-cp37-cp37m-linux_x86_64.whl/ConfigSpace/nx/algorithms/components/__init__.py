from ConfigSpace.nx.algorithms.components.strongly_connected import (
    strongly_connected_components
)

__all__ = ['strongly_connected_components']
